package three;

public class Application {

	public static void main(String[] args) {
		TalkablePerson tp = new TalkablePerson("Firstname", 18);
		tp.talk();
	}
}
