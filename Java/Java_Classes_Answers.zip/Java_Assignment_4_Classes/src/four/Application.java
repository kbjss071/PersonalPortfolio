package four;

public class Application {

	public static void main(String[] args) {
		ConstructorPerson cp = new ConstructorPerson();
		System.out.println("Name: " + cp.name + ", Age: " + cp.age);
	}
}
