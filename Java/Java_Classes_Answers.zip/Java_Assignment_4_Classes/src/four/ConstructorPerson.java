package four;

public class ConstructorPerson {

	String name;
	int age;
	
	public ConstructorPerson() {
		this.name = "Firstname";
		this.age = 19;
	}
	
	
	
	
}
