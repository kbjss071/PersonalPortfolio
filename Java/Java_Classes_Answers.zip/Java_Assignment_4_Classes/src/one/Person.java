package one;

public class Person {

	String name;
	int age;
	
}
