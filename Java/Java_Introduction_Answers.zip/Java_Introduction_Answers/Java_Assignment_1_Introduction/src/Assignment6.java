
public class Assignment6 {

	public static void main(String[] args) {
		float[] a = {10.5f, 11.5f};
		
		System.out.println(a[0] + a[1]);
	}
}
