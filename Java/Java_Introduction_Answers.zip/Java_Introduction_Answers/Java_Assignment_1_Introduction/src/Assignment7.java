
public class Assignment7 {

	public static void main(String[] args) {
		int[] a = {11,22,33};
		
		System.out.println(a[0]- a[1] + a[2]);
	}
}
