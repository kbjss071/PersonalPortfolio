
public class Assignment3 {

	public static void main(String[] args) {
		int x,y;
		x = 15;
		y = 10;
		int z = x + y;
		
		System.out.println(z);
	}
}
