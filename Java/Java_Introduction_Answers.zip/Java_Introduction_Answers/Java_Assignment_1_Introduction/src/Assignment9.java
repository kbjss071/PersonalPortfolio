
public class Assignment9 {

	public static void main(String[] args) {
		boolean bool = true;
		
		System.out.println(bool);
	}
}
