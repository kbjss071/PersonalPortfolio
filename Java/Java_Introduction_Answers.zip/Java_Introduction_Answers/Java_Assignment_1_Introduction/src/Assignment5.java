
public class Assignment5 {

	public static void main(String[] args) {
		String[] a = {"one","two","three","four","five","six","seven","eight","nine","ten"};
		
		//print the 2nd element
		System.out.println(a[1]);
	}
}
