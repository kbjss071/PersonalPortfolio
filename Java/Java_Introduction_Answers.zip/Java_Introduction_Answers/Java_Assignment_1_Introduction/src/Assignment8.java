
public class Assignment8 {

	public static void main(String[] args) {
		float a = 105.678f;
		float b = 222.4871f;
		
		System.out.println(a * b);
	}
}
