
public class Assignment10 {

	public static void main(String[] args) {
		String[] a = {"a","b","c","d", "e"};
		
		System.out.println(a[4]);
	}
}
