public class Assignment2 {

	public static void main(String[] args) {
		int x;
		x = 5;
		System.out.println(x);
	}
	
}