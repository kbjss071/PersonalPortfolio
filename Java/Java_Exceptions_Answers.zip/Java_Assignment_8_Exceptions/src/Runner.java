
public class Runner {

	public void run() throws CustomException {
		throw new CustomException("Tried running but fell");
	}
}
