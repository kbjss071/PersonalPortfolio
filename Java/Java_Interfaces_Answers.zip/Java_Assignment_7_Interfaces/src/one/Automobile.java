package one;

/**
 * An Automobile implements the Movable interface
 *
 */
public class Automobile implements Movable {

	public void move(){
		System.out.println("Moving the object...");
	}
}
