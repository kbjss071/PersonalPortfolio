package one;

public class Application {

	public static void main(String[] args) {
		Movable mv = new Automobile();
		mv.move();
	}
}
