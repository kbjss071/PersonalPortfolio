package one;

public interface Movable {

	public void move();
}
