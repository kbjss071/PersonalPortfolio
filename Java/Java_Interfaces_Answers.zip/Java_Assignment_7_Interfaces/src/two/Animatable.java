package two;

import one.Movable;

public interface Animatable extends Movable{

	public void animate();
}
