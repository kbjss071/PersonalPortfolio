package two;

public class Application2 {

	public static void main(String[] args) {
		Animatable a = new MoverAndAnimate();
		
		a.animate();
		a.move();
	}
}
