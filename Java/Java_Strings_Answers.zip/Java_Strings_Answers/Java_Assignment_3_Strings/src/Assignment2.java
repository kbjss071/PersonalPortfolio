
public class Assignment2 {

	public static void main(String[] args) {
		String one = "abc";
		String two = "ABC";
		
		if (one == two) {
			System.out.println("The strings are equal using (==) ");
		}
		
		if (one.equals(two)){
			System.out.println("The strings are equal using (.equals)");
		}
	}
}
