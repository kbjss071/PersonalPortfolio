
public class Assignment5 {

	public static void main(String[] args) {
		String str = "Hello My Name is Java";
		
		System.out.println(str.substring(str.length()-5));
	}
}
