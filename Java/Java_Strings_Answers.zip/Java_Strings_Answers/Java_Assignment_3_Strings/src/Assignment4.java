
public class Assignment4 {

	public static void main(String[] args) {
		String letters = "abcdefghijklmnopqrstuvwxyz";
		
		int s = letters.indexOf("s");
		int f = letters.indexOf("f");
		
		System.out.println("'s' is at: " + s + ", and 'f' is at: "+ f);
	}
}
