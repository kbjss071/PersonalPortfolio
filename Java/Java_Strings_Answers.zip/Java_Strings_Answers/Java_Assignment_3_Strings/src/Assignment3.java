
public class Assignment3 {

	public static void main(String[] args) {
		String one = "abc";
		String two = new String("abc");
		
		if (one == two){
			System.out.println("The strings are equivalent");
		}else {
			System.out.println("The strings are NOT equivalent");
		}
	}
}
