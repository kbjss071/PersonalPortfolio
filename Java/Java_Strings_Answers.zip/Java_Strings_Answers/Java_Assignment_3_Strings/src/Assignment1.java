
public class Assignment1 {

	public static void main(String[] args) {
		String one = "Hello ";
		String two = "Aron";
		
		String result = one + two; //concatenation
		System.out.println(result);
	}
}
