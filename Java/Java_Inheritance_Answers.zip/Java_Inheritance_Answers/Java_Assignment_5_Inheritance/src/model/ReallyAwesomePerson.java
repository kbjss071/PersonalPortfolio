package model;

public class ReallyAwesomePerson extends AwesomePerson {

	public ReallyAwesomePerson() {
		System.out.println("In ReallyAwesomePerson constructor...");
	}
	
	public void talk(String message){
		System.out.println(message);
	}
}
