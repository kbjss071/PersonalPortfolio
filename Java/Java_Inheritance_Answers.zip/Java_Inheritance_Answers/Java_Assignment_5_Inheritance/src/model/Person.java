package model;

public class Person {

	protected String name;
	protected int age;
	
	public Person() {
		System.out.println("In Person constructor...");
	}
}
