package game;

public class Player extends GameObject {

	@Override
	public void update() {
		System.out.println("Updating Person's hitpoints...");
	}
}
