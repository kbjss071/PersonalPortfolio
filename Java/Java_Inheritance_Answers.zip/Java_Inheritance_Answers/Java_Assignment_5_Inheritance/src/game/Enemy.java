package game;

public class Enemy extends GameObject {

	@Override
	public void update() {
		System.out.println("Updating enemy's hitpoints...");
	}
}
