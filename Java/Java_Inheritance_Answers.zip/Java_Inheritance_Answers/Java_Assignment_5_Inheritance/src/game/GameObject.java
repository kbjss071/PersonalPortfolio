package game;

public class GameObject {

	public void update(){
		System.out.println("In the update method...");
	}
}
