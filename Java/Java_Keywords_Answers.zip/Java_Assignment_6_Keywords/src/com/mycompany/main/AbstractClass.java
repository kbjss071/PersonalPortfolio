package com.mycompany.main;

public abstract class AbstractClass {

	public abstract void run();
}
