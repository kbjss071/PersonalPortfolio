package com.mycompany.main;

public class ConcreteClass extends AbstractClass {

	@Override
	public void run() {
		System.out.println("Running the class...");
	}
}
