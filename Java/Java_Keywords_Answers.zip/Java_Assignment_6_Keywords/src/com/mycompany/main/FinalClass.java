package com.mycompany.main;

public class FinalClass {

	final int myConstant = 1;
}
