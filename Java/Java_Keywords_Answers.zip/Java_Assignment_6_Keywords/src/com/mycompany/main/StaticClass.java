package com.mycompany.main;

public class StaticClass {

	public static float add(float x, float y){
		return x + y;
	}
}
